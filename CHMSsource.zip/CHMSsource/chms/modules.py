import difflib
import os
import re
import requests
from . import config
from .strings import strings


class Module:
    def __init__(self, content, repo, file_name, name, description, author, commands, hikkawe):
        self.content = content
        self.repo = repo
        self.file_name = file_name
        self.name = name
        self.description = description
        self.author = author
        self.commands = commands
        self.hikkawe = hikkawe # too many kinda the same lines..?


class Loader:
    def __init__(self):
        self.modules = []

    def lookup(self, modname):
        return next(
            (
                mod
                for mod in self.modules
                if mod.name.lower() == modname.lower()
            ),
            False,
        )

    def search(self, modname):
        return self.lookup(
            next(
                (
                    reversed(
                        sorted(
                            [
                                module.name
                                for module in self.modules
                            ],
                            key=lambda x: difflib.SequenceMatcher(
                                None,
                                modname,
                                x,
                            ).ratio(),
                        )
                    )
                ),
                None,
            )
        )

    def reindex(self):
        self.modules = []

        for repo in config.REPOS:
            full_modules = requests.get(f"{repo}/full.txt").text

            for module in full_modules.splitlines():
                data = requests.get(f"{repo}/{module}.py").text

                description = re.search(r"class .*\(.*\):\n *\"\"\"(.*)\"\"\"", data, flags=re.M)
                description = ((description.group(1)) if description else strings["no_desc"])

                modname = re.search(r"class (.*)\(.*Module\):", data, flags=re.M)
                modname = modname.group(1)

                author = re.search(r"# *meta *developer: *(.*)", data, flags=re.M)
                author = ((author.group(1)) if author else "Unknown")

                commands_m = re.finditer(r"(def (.*)cmd\(.*|@loader\.command\(.*\)\n *async def (.*)\()", data, flags=re.M)
                commands = []

                hikkawe = "# scope: hikka_we" in data

                for command in commands_m: # this looks dumb
                    if command.group(1).lower().startswith("@loader"):
                        commands.append(command.group(3))
                    else:
                        commands.append(command.group(2))

                module = Module(data, repo, module, modname, description, author, commands, hikkawe)
                self.modules.append(module)

    async def aioreindex(self):
        self.reindex() # thats bad, i think
