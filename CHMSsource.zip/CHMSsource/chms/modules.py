import difflib
import os
import re


class Module:
    def __init__(self, file_name, name, description, author, commands, hikkawe):
        self.file_name = file_name
        self.name = name
        self.description = description
        self.author = author
        self.commands = commands
        self.hikkawe = hikkawe


class Loader:
    def __init__(self):
        self.modules = []

    def lookup(self, modname):
        return next(
            (
                mod
                for mod in self.modules
                if mod.name.lower() == modname.lower()
            ),
            False,
        )

    def search(self, modname):
        return self.lookup(
            next(
                (
                    reversed(
                        sorted(
                            [
                                module.name
                                for module in self.modules
                            ],
                            key=lambda x: difflib.SequenceMatcher(
                                None,
                                modname,
                                x,
                            ).ratio(),
                        )
                    )
                ),
                None,
            )
        )

    def reindex(self):
        self.modules = []
        for mod in os.listdir("./chms/modules/"):
            with open(f"./chms/modules/{mod}", "r", encoding="utf-8") as file:
                data = file.read()

                description = re.search(r"class .*\(.*\):\n *\"\"\"(.*)\"\"\"", data, flags=re.M)
                description = ((description.group(1)) if description else None)

                modname = re.search(r"class (.*)\(.*Module\):", data, flags=re.M)
                modname = modname.group(1)

                author = re.search(r"# *meta *developer: *(.*)", data, flags=re.M)
                author = ((author.group(1)) if author else "Unknown")

                commands_m = re.finditer(r"(def (.*)cmd\(.*|@loader\.command\(.*\)\n *async def (.*)\()", data, flags=re.M)
                commands = []

                hikkawe = "# scope: hikka_we" in data

                for command in commands_m:
                    if command.group(1).lower().startswith("@loader"):
                        commands.append(command.group(3))
                    else:
                        commands.append(command.group(2))

                module = Module(mod, modname, description, author, commands, hikkawe)
                self.modules.append(module)

    async def aioreindex(self):
        self.reindex()   
