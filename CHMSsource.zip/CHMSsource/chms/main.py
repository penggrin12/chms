from aiogram import Bot, Dispatcher, executor
from aiogram.dispatcher.handler import CancelHandler, current_handler
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.types.inline_keyboard import *
from aiogram.utils.exceptions import Throttled
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from . import config, modules
from .strings import strings

import aioschedule as schedule

import logging
import asyncio
import re

logging.basicConfig(level=logging.INFO)

storage = MemoryStorage()
bot = Bot(token=config.TOKEN, parse_mode='html')
dp = Dispatcher(bot, storage=storage)
loader = modules.Loader()


def rate_limit(limit, key=None):
    def decorator(func):
        setattr(func, 'throttling_rate_limit', limit)
        if key:
            setattr(func, 'throttling_key', key)
        return func

    return decorator


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, limit=1, key_prefix='antiflood_'):
        self.rate_limit = limit
        self.prefix = key_prefix
        super(ThrottlingMiddleware, self).__init__()

    async def on_process_message(self, message, data):
        handler = current_handler.get()
        dispatcher = Dispatcher.get_current()
        
        if handler:
            limit = getattr(handler, 'throttling_rate_limit', self.rate_limit)
            key = getattr(handler, 'throttling_key', f"{self.prefix}_{handler.__name__}")
        else:
            limit = self.rate_limit
            key = f"{self.prefix}_message"

        try:
            await dispatcher.throttle(key, rate=limit)
        except Throttled as t:
            await self.message_throttled(message, t)
            raise CancelHandler()

    async def message_throttled(self, message, throttled):
        handler = current_handler.get()
        dispatcher = Dispatcher.get_current()
        if handler:
            key = getattr(handler, 'throttling_key', f"{self.prefix}_{handler.__name__}")
        else:
            key = f"{self.prefix}_message"

        delta = throttled.rate - throttled.delta

        if throttled.exceeded_count <= 2:
            await message.reply('Too many requests!')

        await asyncio.sleep(delta)

        thr = await dispatcher.check_key(key)

        if thr.exceeded_count == throttled.exceeded_count:
            await message.reply('Unlocked.')


@dp.callback_query_handler()
async def callback(query):
    if (not query.data.startswith("load:")) and (not query.data.startswith("source:")):
        return

    split = query.data.lower().split(":")
    module = loader.search(split[1])

    if not module:
        await query.message.reply(strings["not_found"])
        return

    if query.data.startswith("source:"):
        await bot.send_document(
            query.message.chat.id,
            document=module.content.encode("utf-8"),
            caption=strings["module_source"].format(module.name)
        )
        return await query.answer()

    await bot.send_document(
        query.message.chat.id,
        document=module.content.encode("utf-8"),
        caption=f"#cinstall\n\n{strings['dont_touch']}"
    )

    await query.answer(strings["install_sent"])


@dp.message_handler(commands=['start', 'help'])
async def cmd_start(message):
    await message.reply(strings["welcome"])


@dp.message_handler()
async def new_message(message):
    split = message.text.lower().split(":")

    if split[0] == "#done":
        await message.answer(strings["installed"])
        await message.delete()
        return

    module = loader.search(message.text)

    if not module:
        await message.reply(strings["not_found"])
        return

    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(strings["install_btn"], callback_data=f"load:{module.name}"),
        InlineKeyboardButton(strings["source_btn"], callback_data=f"source:{module.name}"),
    )

    await message.reply(
        strings["mod"].format(
            module.name,
            module.author,
            module.description,
            (strings["hikkawe"] if module.hikkawe else ""),
            ('\n'.join([f"💠 <code>.{cmd if not cmd.endswith('cmd') else cmd[:-3]}</code>" for cmd in module.commands]))
            if module.commands else strings["no_commands"]
        ),
        reply_markup=keyboard
    )


def main():
    loader.reindex()
    schedule.every(15).minutes.do(loader.aioreindex)
    dp.middleware.setup(ThrottlingMiddleware())
    executor.start_polling(dp, skip_updates=True)
