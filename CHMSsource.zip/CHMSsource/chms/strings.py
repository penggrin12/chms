from . import config

strings = {
    "welcome": (
        'Use this chat to search for Un-Official Hikka Modules\n'
        '(You will need to install <a href="https://t.me/HikkaWE/34">CHMS</a> on your hikka for this bot to work)\n' 
        '\n'
        f'If you want publish a module on here, just contact {config.CONTACT}.\n'
        '(Also you can copy this bot and host any modules you want, <a href="https://github.com/penggrin12/chms">here</a>)' if config.AD else ''
    ),
    "mod": (
        "✨ <b>{}</b>\n" # name
        "👤 Made by: <b>{}</b>\n" # author
        "\n"
        "ℹ️ {}\n" # description
        "{}" # hikkawe
        "\n"
        "🪐 Commands:\n"
        "{}" # commands
    ),
    "installed": "✅ Module installed!",
    "not_found": "❌ Module not found!",
    "module_source": "🗒 <b>{}</b> Source code",
    "install_btn": "📁 Install via CHMS",
    "source_btn": "🗒 Source Code",
    "install_sent": "🔃 Installation Request sent!",
    "hikkawe": "ℹ️ Hikka WE Compatible!\n",
    "no_commands": "❌ No commands found!",
    "dont_touch": "⚠️ This is a message used by your userbot, dont touch it\n⚠️ If it doesn't do anything for long enough, make sure you downloaded an updated CHMS module (/start)"
}