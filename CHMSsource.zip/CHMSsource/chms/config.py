TOKEN = 'TOKEN'  # Bot Token from @BotFather
CONTACT = '@USERNAME' # A way to contact you
AD = True # Display a link to this bot source in /start