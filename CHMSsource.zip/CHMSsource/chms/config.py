TOKEN = 'TOKEN'  # Bot Token from @BotFather
CONTACT = '@USERNAME' # A way to contact you
REPOS = ['https://github.com/penggrin12/hikkamods/raw/main', 'https://github.com/Yaroslav1734/modules/raw/main'] # From what repos bot will pull modules (each of them MUST NOT end with /)
AD = True # Display a link to this bot source in /start